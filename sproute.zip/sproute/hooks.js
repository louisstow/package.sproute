module.exports = {
	"get": function (block) {
		console.log("GET", block);
		return "FUCK OFF"
	}
}