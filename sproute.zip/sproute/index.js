
var appName = "reddit";
var dir = "example/reddit";

var App = require("./app");
var app = new App(appName, dir);
