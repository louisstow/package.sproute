#!/bin/bash

brew install node
brew install mongo

cd ../sproute
npm install
