var Sproute = require("./sproute/app");

new Sproute(".");
